"""
URL configuration for cug project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from cugweb import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.homepage, name='homepage'), #home page
    path('ad_login',views.ad_login, name ='ad_login'), #admin login page
    path('dealer_login',views.dealer_login, name ='dealer_login'), #delar login page
    
    path('dealer_login/dealer_home',views.dealer_home, name='dealer_home'), #main page of dealer
    path('dealer_login/dealer_home/dealer_viewcug',views.dealer_viewcug, name='dealer_viewcug'),
    path('dealer_login/dealer_home/dealer_activate',views.dealer_activate, name='dealer_activate'),
    path('dealer_login/dealer_home/dealer_deactivate',views.dealer_deactivate, name='dealer_deactivate'),

    path('dealer_login/dealer_home/dealer_alloc',views.dealer_alloc, name='dealer_alloc'),
    path('dealer_login/dealer_home/dealer_plan',views.dealer_plan, name='dealer_plan'),
    
    path('ad_login/ad_home',views.ad_home, name='ad_home'),
    path('ad_login/ad_home/ad_bill',views.ad_bill, name='ad_bill'),
    path('ad_login/ad_home/ad_allot',views.ad_allot, name='ad_allot'),
    path('ad_login/ad_home/ad_status',views.ad_status, name='ad_status'),
    path('ad_login/ad_home/ad_newcug',views.ad_newcug, name='ad_newcug'),
]
