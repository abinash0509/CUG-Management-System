from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.db import connection
import mysql.connector
import traceback
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
import pandas as pd
import re




def homepage(request):
    return render(request, 'home.html')

def ad_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('ad_home')
        else:
            error_message = 'Invalid username or password'
            return render(request, 'ad_login.html', {'error_message': error_message})
        
    return render(request, 'ad_login.html')

def dealer_login(request):
     if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('dealer_login/dealer_home')
        else:
            error_message = 'Invalid username or password'
            return render(request, 'dealer_login.html', {'error_message': error_message})
        
     return render(request, 'dealer_login.html')

def dealer_home(request):
    return render(request, 'dealer_home.html')


def dealer_viewcug(request):
    if request.method == "POST":
        mobileno = request.POST.get('mobileno')
        # password = request.POST.get('password')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            query = "SELECT * FROM cugmaster WHERE mobile_num = %s "
            cursor.execute(query, (mobileno,))
            result = cursor.fetchall()

            if result:
                return render(request, "dealer_viewcug.html", {'result': result})
            else:
                return HttpResponse('<script>alert("Record not found."); window.location.href="/dealer_login/dealer_home/dealer_viewcug";</script>')
        except Exception as e:
            print("Error occurred:", e)
            return HttpResponse('<script>alert("An error occurred. Please try again.");</script>')
        
    return render(request, 'dealer_viewcug.html')

    

def dealer_activate(request):
    if request.method == 'POST':
        unit = request.POST.get('unit')
        mobile_num = request.POST.get('mobileno')
        emp_name = request.POST.get('name')
        pf_num = request.POST.get('pfno')
        billunit_num = request.POST.get('billno')
        designation = request.POST.get('designation')
        emp_status = request.POST.get('status')
        plan = request.POST.get('plan')
        department = request.POST.get('department')
        allocation = request.POST.get('allocation')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            select_query = "INSERT INTO cugmaster (unit, mobile_num, emp_name, pf_num, billunit_num, designation, emp_status, plan, department, allocation) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(select_query, (unit,mobile_num,emp_name,pf_num,billunit_num,designation,emp_status,plan,department,allocation))
            
            connection.commit()
            return HttpResponse('<script>alert("Record inserted successfully."); window.location.href = "/dealer_login/dealer_home/dealer_activate";</script>')


        except Exception as e:
            print("Error occurred:", e)
            return redirect('dealer_activate.html')
            

    return render(request, 'dealer_activate.html')

def dealer_deactivate(request):
    if request.method == 'POST':  # Make sure 'POST' is capitalized
        mobile_num = request.POST.get('mobileno')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            insert_query = "INSERT INTO history SELECT * FROM cugmaster WHERE mobile_num = %s"  # Fixed typo 'VLAUES' to 'VALUES'
            cursor.execute(insert_query, (mobile_num,))

            delete_query = "DELETE FROM cugmaster WHERE mobile_num = %s"
            cursor.execute(delete_query,(mobile_num,))
            connection.commit()
            cursor.close()
            connection.close()
            return HttpResponse('<script>alert("Record deactivated"); window.location.href = "/dealer_login/dealer_home/dealer_viewcug";</script>')

        except Exception as e:
            print("Error occurred:", e)
            return redirect('dealer_deactivate.html')

    return render(request, 'dealer_deactivate.html')




def dealer_alloc(request):
    if request.method == 'POST':
        unit = request.POST.get('unit')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            if unit!= 'all':

                query = "SELECT allocation, COUNT(CASE WHEN plan = 'A' THEN 1 END) AS plan_a_count,COUNT(CASE WHEN plan = 'B' THEN 1 END) AS plan_b_count,COUNT(CASE WHEN plan = 'C' THEN 1 END) AS plan_c_count,((COUNT(CASE WHEN plan = 'A' THEN 1 END) * 74.61)+ (COUNT(CASE WHEN plan = 'B' THEN 1 END) * 59.06)+ (COUNT(CASE WHEN plan = 'C' THEN 1 END) * 39.9)) AS total_amount FROM cugdata.cugmaster WHERE unit = %s GROUP BY allocation WITH ROLLUP"
                cursor.execute(query, (unit,))
                results = cursor.fetchall()

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="plan_report_{unit}.pdf"'

                # Create a PDF canvas
                p = canvas.Canvas(response, pagesize=letter)

                # Set up the PDF content
                p.setFont("Helvetica-Bold", 16)
                p.setFillColor(colors.blue)
                p.drawString(50, 750, "East Coast Railway")
                p.setFillColor(colors.black)
                p.setFont("Helvetica", 14)
                p.drawString(50, 700, f"Allocation Report - Unit {unit}")

                # Draw the table headers
                table_headers = ["Allocation", "Number of A","Number of B","Number of C", "Total Amount"]
                column_width = 110
                x= 50
                y = 650

                for header in table_headers:
                     p.setFont("Helvetica-Bold", 12)
                     p.drawString(x, y, header)
                     x += column_width

                line_y = y - 10
                p.line(50, line_y, x, line_y)

                # Draw the table rows
                p.setFont("Helvetica", 12)
                for result in results:
                     allocation, number_of_A,number_of_B,number_of_C, total_amount = result
                     x = 50
                     y -= 30
                     p.drawString(x, y, str(allocation))
                     x += column_width
                     p.drawString(x, y, str(number_of_A))
                     x += column_width
                     p.drawString(x, y, str(number_of_B))
                     x += column_width
                     p.drawString(x, y, str(number_of_C))
                     x += column_width
                     p.drawString(x, y, str(total_amount))
                     

                p.showPage()
                p.save()
                return response

            
            else:
                query = "SELECT allocation, COUNT(CASE WHEN plan = 'A' THEN 1 END) AS plan_a_count,COUNT(CASE WHEN plan = 'B' THEN 1 END) AS plan_b_count,COUNT(CASE WHEN plan = 'C' THEN 1 END) AS plan_c_count,((COUNT(CASE WHEN plan = 'A' THEN 1 END) * 76.41)+ (COUNT(CASE WHEN plan = 'B' THEN 1 END) * 59.06)+ (COUNT(CASE WHEN plan = 'C' THEN 1 END) * 39.9)) AS total_amount FROM cugdata.cugmaster GROUP BY allocation WITH ROLLUP"
                cursor.execute(query)
                results = cursor.fetchall()

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="plan_report_{unit}.pdf"'

                # Create a PDF canvas
                p = canvas.Canvas(response, pagesize=letter)

                # Set up the PDF content
                p.setFont("Helvetica-Bold", 16)
                p.setFillColor(colors.blue)
                p.drawString(50, 750, "East Coast Railway")
                p.setFillColor(colors.black)
                p.setFont("Helvetica", 14)
                p.drawString(50, 700, f"Allocation Report - Unit {unit}")

                # Draw the table headers
                table_headers = ["Allocation", "Number of A","Number of B","Number of C", "Total Amount"]
                column_width = 110
                x= 50
                y = 650

                for header in table_headers:
                     p.setFont("Helvetica-Bold", 12)
                     p.drawString(x, y, header)
                     x += column_width

                line_y = y - 10
                p.line(50, line_y, x, line_y)

                # Draw the table rows
                p.setFont("Helvetica", 12)
                for result in results:
                     allocation, number_of_A,number_of_B,number_of_C, total_amount = result
                     x = 50
                     y -= 30
                     p.drawString(x, y, str(allocation))
                     x += column_width
                     p.drawString(x, y, str(number_of_A))
                     x += column_width
                     p.drawString(x, y, str(number_of_B))
                     x += column_width
                     p.drawString(x, y, str(number_of_C))
                     x += column_width
                     p.drawString(x, y, str(total_amount))
                     

                p.showPage()
                p.save()
                return response

                
        except Exception as e:
            print("Error occurred:", e)
            return render(request,'dealer_alloc.html')
            
    return render(request, 'dealer_alloc.html')

def dealer_plan(request):
    if request.method == 'POST':
        plan = request.POST.get('plan')
        rate = request.POST.get('rate')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor() 

            query = "SELECT unit, COUNT(*) AS total_plan, COUNT(*) * %s AS total_amount FROM cugmaster WHERE plan = %s AND unit IN ('CON', 'MCS', 'HQ') GROUP BY unit WITH ROLLUP"

            cursor.execute(query,(rate,plan,))
            results = cursor.fetchall()

            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="plan_report_{plan}.pdf"'

            # Create a PDF canvas
            p = canvas.Canvas(response, pagesize=letter)

            # Set up the PDF content
            p.setFont("Helvetica-Bold", 16)
            p.setFillColor(colors.blue)
            p.drawString(50, 750, "East Coast Railway")
            p.setFillColor(colors.black)
            p.setFont("Helvetica", 14)
            p.drawString(50, 700, f"Plan Report - Plan {plan}")

            # Draw the table headers
            table_headers = ["Unit", "Total plan", "Total Amount(in Rs.)"]
            column_width = 110
            x= 50
            y = 650

            for header in table_headers:
                     p.setFont("Helvetica-Bold", 12)
                     p.drawString(x, y, header)
                     x += column_width

            line_y = y - 10
            p.line(50, line_y, x, line_y)

                # Draw the table rows
            p.setFont("Helvetica", 12)
            for result in results:
                     unit, total_plan, total_amount = result
                     x = 50
                     y -= 30
                     p.drawString(x, y, str(unit))
                     x += column_width
                     p.drawString(x, y, str(total_plan))
                     x += column_width
                     p.drawString(x, y, str(total_amount))
                     

            p.showPage()
            p.save()
            return response
                       
            


        except Exception as e:
             print("Error occurred:", e)
             return render(request, 'dealer_plan.html')
    
    return render(request, 'dealer_plan.html') 

def ad_home(request):
    return render(request, 'ad_home.html')

def modify_column_name(column_name):
    # Remove special characters and replace spaces with underscores
    modified_name = re.sub(r'\W+', '', column_name.replace(' ', '_'))
    return modified_name

def infer_mysql_data_type(data_type):
    if data_type == 'object':
        return 'VARCHAR(255)'
    elif data_type == 'int64':
        return 'BIGINT'
    elif data_type == 'float64':
        return 'DOUBLE'
    else:
        return 'VARCHAR(255)'

def ad_bill(request):
    if request.method == 'POST':
        excel_file = request.FILES['excel_file']
        try:
            # Read the Excel file into a pandas DataFrame
            if excel_file.name.endswith('.xlsx') or excel_file.name.endswith('.xls'):
                df = pd.read_excel(excel_file)

            # Modify column names to comply with MySQL naming requirements
                df.columns = [modify_column_name(col) for col in df.columns]

            # Connect to the MySQL database
                conn = mysql.connector.connect(
                    host="127.0.0.1",
                    user="root",
                    password="rootpassword",
                    database="cugdata"
                )   

            # Create a new table named 'uploads' in the database
                table_name = 'upload'
                cursor = conn.cursor()

           # Construct the CREATE TABLE query
                create_table_query = f"CREATE TABLE {table_name} ("
                for col_name, data_type in zip(df.columns, df.dtypes):
                    column_type = infer_mysql_data_type(data_type)
                    create_table_query += f"{col_name} {column_type}, "
                create_table_query = create_table_query.rstrip(', ') + ");"

                cursor.execute(f"DROP TABLE IF EXISTS {table_name};")
                cursor.execute(create_table_query)

            # Insert the data from the DataFrame into the table
                for _, row in df.iterrows():
                    values = ', '.join([f"'{value}'" for value in row])
                    insert_query = f"INSERT INTO {table_name} VALUES ({values});"
                    cursor.execute(insert_query)

                conn.commit()

            # Close the database connection
                cursor.close()
                conn.close()

            # Provide a success message or redirect to another page
                return HttpResponse('<script>alert("File uploaded"); window.location.href="/ad_login/ad_home/ad_bill";</script>')
            else:
                return HttpResponse('<script>alert("not a excel file"); window.location.href="/ad_login/ad_home/ad_bill";</script>')

        except Exception as e:
            print("Error occurred:", e)
            return HttpResponse('<script>alert("error occured"); window.location.href="/ad_login/ad_home/ad_bill";</script>')

    return render(request, 'ad_bill.html')

def ad_allot(request):

    if request.method == "POST":
        mobileno = request.POST.get('mobileno')
        # password = request.POST.get('password')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            query = "SELECT * FROM history WHERE mobile_num = %s "
            cursor.execute(query, (mobileno,))
            result = cursor.fetchall()

            if result:
                return render(request, "ad_allot.html", {'result': result})
            else:
                return HttpResponse('<script>alert("Record not found."); window.location.href="/ad_login/ad_home/ad_allot";</script>')
        except Exception as e:
            print("Error occurred:", e)
            return HttpResponse('<script>alert("An error occurred. Please try again.");</script>')
    return render(request, 'ad_allot.html')

def ad_status(request):
    if request.method == 'POST':
        mobileno = request.POST.get('mobileno')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            query = "SELECT * FROM cugmaster WHERE mobile_num = %s"
            cursor.execute(query,(mobileno,))
            result = cursor.fetchall()

            if result:
                return render(request, 'ad_status.html', {'result': result})
            else:
                return HttpResponse('<script>alert("Mobile number is deactivated"); window.location.href="/ad_login/ad_home/ad_status";</script>')

        except Exception as e:
            print("Error occurred:", e)
            return HttpResponse('<script>alert("An error occurred. Please try again.");</script>')
        
    return render(request, 'ad_status.html')

def ad_newcug(request):
    if request.method == 'POST':
        unit = request.POST.get('unit')
        mobile_num = request.POST.get('mobileno')
        emp_name = request.POST.get('name')
        pf_num = request.POST.get('pfno')
        billunit_num = request.POST.get('billno')
        designation = request.POST.get('designation')
        emp_status = request.POST.get('status')
        plan = request.POST.get('plan')
        department = request.POST.get('department')
        allocation = request.POST.get('allocation')

        try:
            connection = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="rootpassword",
                database="cugdata"
            )
            cursor = connection.cursor()

            select_query = "INSERT INTO cugmaster (unit, mobile_num, emp_name, pf_num, billunit_num, designation, emp_status, plan, department, allocation) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(select_query, (unit,mobile_num,emp_name,pf_num,billunit_num,designation,emp_status,plan,department,allocation))
            
            connection.commit()
            return HttpResponse('<script>alert("Record inserted successfully."); window.location.href = "/ad_login/ad_home/ad_newcug";</script>')


        except Exception as e:
            print("Error occurred:", e)
            return render(request,'ad_newcug.html')
    return render(request, 'ad_newcug.html')
