from django.apps import AppConfig


class CugwebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cugweb'
